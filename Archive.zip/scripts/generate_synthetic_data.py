"""
PIDL Araştırma Sistemi - Sentetik Veri Üretici (v2.0)
=====================================================
150 katılımcı için tam araştırma verisi üretir:
- Demografik bilgiler
- Yetkinlik profilleri
- UserVector (10 boyut)
- Persona önerileri (Similar + Complementary)
- 6 görev verisi (Pre/Post test, NASA-TLX, değerlendirmeler)
- Adaptive mod kararları
- Final değerlendirme

Kullanım:
    python scripts/generate_synthetic_data.py
"""

import json
import uuid
import random
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Any, Tuple
import os
import sys

# Proje kök dizinini ekle
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# =============================================================================
# SABİTLER VE YAPILANDIRMA
# =============================================================================

# Katılımcı dağılımı (Gerçekçi - Normal dağılıma yakın)
# Competent en yaygın, uç seviyeler (novice/expert) daha az
PARTICIPANT_DISTRIBUTION = {
    "novice": 18,              # %12 - En az deneyimli (az bulunur)
    "advanced_beginner": 32,   # %21.3 - Öğrenme aşamasında
    "competent": 48,           # %32 - En yaygın seviye (çoğunluk)
    "proficient": 35,          # %23.3 - Deneyimli
    "expert": 17               # %11.3 - Uzman (nadir)
}
# Toplam: 150 katılımcı

# Dreyfus level mapping
LEVEL_MAPPING = {
    "novice": 0.1,
    "advanced_beginner": 0.3,
    "competent": 0.5,
    "proficient": 0.7,
    "expert": 0.9
}

# Learning goal by level
LEARNING_GOAL_MAPPING = {
    "novice": 0.9,
    "advanced_beginner": 0.9,
    "competent": 0.6,
    "proficient": 0.3,
    "expert": 0.3
}

# Persona tanımları
TECHNOLOGY_PERSONAS = [
    {"name": "tech_novice", "code_complexity": 0.2, "verbosity": 0.9, "technical_depth": 0.2,
     "pedagogical_focus": 0.9, "modularity": 0.3, "learning_support": 0.9, "production_readiness": 0.2},
    {"name": "tech_advanced_beginner", "code_complexity": 0.35, "verbosity": 0.75, "technical_depth": 0.35,
     "pedagogical_focus": 0.7, "modularity": 0.5, "learning_support": 0.75, "production_readiness": 0.4},
    {"name": "tech_competent", "code_complexity": 0.55, "verbosity": 0.5, "technical_depth": 0.65,
     "pedagogical_focus": 0.25, "modularity": 0.7, "learning_support": 0.55, "production_readiness": 0.75},
    {"name": "tech_proficient", "code_complexity": 0.75, "verbosity": 0.35, "technical_depth": 0.8,
     "pedagogical_focus": 0.15, "modularity": 0.85, "learning_support": 0.35, "production_readiness": 0.9},
    {"name": "tech_expert", "code_complexity": 0.9, "verbosity": 0.2, "technical_depth": 0.95,
     "pedagogical_focus": 0.1, "modularity": 0.95, "learning_support": 0.2, "production_readiness": 0.98}
]

EDUCATION_PERSONAS = [
    {"name": "edu_novice", "code_complexity": 0.15, "verbosity": 0.95, "technical_depth": 0.15,
     "pedagogical_focus": 0.95, "modularity": 0.25, "learning_support": 0.95, "production_readiness": 0.1},
    {"name": "edu_advanced_beginner", "code_complexity": 0.3, "verbosity": 0.8, "technical_depth": 0.3,
     "pedagogical_focus": 0.85, "modularity": 0.45, "learning_support": 0.85, "production_readiness": 0.3},
    {"name": "edu_competent", "code_complexity": 0.5, "verbosity": 0.6, "technical_depth": 0.5,
     "pedagogical_focus": 0.6, "modularity": 0.6, "learning_support": 0.7, "production_readiness": 0.5},
    {"name": "edu_proficient", "code_complexity": 0.7, "verbosity": 0.4, "technical_depth": 0.7,
     "pedagogical_focus": 0.4, "modularity": 0.8, "learning_support": 0.5, "production_readiness": 0.7},
    {"name": "edu_expert", "code_complexity": 0.85, "verbosity": 0.25, "technical_depth": 0.85,
     "pedagogical_focus": 0.3, "modularity": 0.9, "learning_support": 0.35, "production_readiness": 0.85}
]

# Görev bilgileri
TASKS = [
    {"id": 1, "name": "Simple Storage", "complexity": 0.3, "topic": "Temel veri saklama"},
    {"id": 2, "name": "Token Transfer", "complexity": 0.4, "topic": "Token transferi"},
    {"id": 3, "name": "Access Control", "complexity": 0.5, "topic": "Erişim kontrolü"},
    {"id": 4, "name": "Event Logging", "complexity": 0.6, "topic": "Olay kaydı"},
    {"id": 5, "name": "Multi-Sig Wallet", "complexity": 0.7, "topic": "Çoklu imza cüzdan"},
    {"id": 6, "name": "Upgradeable Contract", "complexity": 0.8, "topic": "Yükseltilebilir kontrat"}
]

# Demografik seçenekler
DEMOGRAPHICS = {
    "ages": list(range(20, 56)),
    "genders": ["Erkek", "Kadın", "Belirtmek istemiyorum"],
    "gender_weights": [0.65, 0.30, 0.05],
    "education": ["Lisans", "Yüksek Lisans", "Doktora", "Lise", "Ön Lisans"],
    "education_weights": [0.45, 0.30, 0.15, 0.05, 0.05],
    "work_fields": ["Teknoloji/Yazılım", "Finans/Bankacılık", "Eğitim/Akademi", 
                    "Mühendislik", "Danışmanlık", "Diğer"],
    "work_field_weights": [0.40, 0.20, 0.15, 0.10, 0.10, 0.05]
}

# Açık uçlu cevap şablonları (Zenginleştirilmiş)
OPEN_ENDED_TEMPLATES = {
    "best_aspect": {
        "kısa": [
            "Açıklamalar iyiydi",
            "Kod kalitesi güzel",
            "Anlaşılır",
            "Faydalı örnekler",
            "İyi yapılandırılmış"
        ],
        "orta": [
            "Kodun açıklamalı olması çok faydalıydı",
            "Modüler yapı öğrenmeyi kolaylaştırdı",
            "Güvenlik önlemlerinin detaylı açıklanması",
            "Adım adım yaklaşım çok yardımcı oldu",
            "Gerçek dünya örnekleri ile bağlantı kurması",
            "Gas optimizasyonu önerileri yararlıydı",
            "Hata yönetimi açıklamaları güzeldi",
            "Best practice'lere uygun kod üretildi"
        ],
        "detaylı": [
            "Özellikle modifier'ların nasıl çalıştığını anlatan kısım çok açıklayıcıydı, daha önce bu kadar net anlamamıştım",
            "Kodun her satırının neden yazıldığını açıklaması, sadece kopyala-yapıştır değil gerçek öğrenme sağladı",
            "Gas optimizasyonu konusunda verilen öneriler production'da işime yarayacak bilgiler içeriyordu",
            "Güvenlik açıkları konusunda verilen uyarılar ve çözüm önerileri çok değerli, reentrancy attack'ı ilk kez bu kadar iyi anladım",
            "Event'lerin neden önemli olduğunu ve nasıl kullanılacağını gösteren örnekler çok öğreticiydi"
        ]
    },
    "improvement_needed": {
        "kısa": [
            "Daha fazla örnek",
            "Biraz karmaşık",
            "Eksik açıklama",
            "-",
            "Yok"
        ],
        "orta": [
            "Daha fazla örnek olabilirdi",
            "Bazı kavramlar daha detaylı açıklanabilirdi",
            "Performans iyileştirmeleri eklenebilirdi",
            "Test senaryoları daha kapsamlı olabilirdi",
            "Alternatif yaklaşımlar gösterilebilirdi",
            "Hata mesajları daha açıklayıcı olabilirdi",
            "Edge case'ler daha fazla ele alınabilirdi"
        ],
        "detaylı": [
            "Proxy pattern kullanımında storage collision konusu biraz havada kaldı, daha detaylı açıklama faydalı olurdu",
            "Multi-sig wallet'ta threshold değişikliği senaryoları eksik kalmış, gerçek kullanımda bu çok kritik",
            "Gas estimation konusunda daha fazla pratik bilgi olabilirdi, testnette deneme yapmadan production'a çıkmak riskli",
            "Farklı Solidity versiyonları arasındaki farklar belirtilseydi daha faydalı olurdu",
            "Error handling kısmında custom error'lar yerine require kullanılmış, yeni standartlara geçilebilirdi"
        ]
    },
    "hardest_task": {
        "kısa": [
            "Multi-Sig Wallet",
            "Upgradeable Contract",
            "Access Control",
            "Hepsi zordu",
            "Hiçbiri çok zor değildi"
        ],
        "orta": [
            "Multi-Sig Wallet en zorlayıcıydı",
            "Upgradeable Contract karmaşıktı",
            "Access Control mantığını anlamak zaman aldı",
            "Event Logging performans optimizasyonu zordu",
            "Token Transfer'de edge case'ler zorladı",
            "Storage yapısını anlamak zaman aldı",
            "Tüm görevler dengeli zorlukdaydı"
        ],
        "detaylı": [
            "Multi-Sig Wallet kesinlikle en zoruydu çünkü hem mapping yapısını hem de approval mekanizmasını aynı anda düşünmek gerekiyordu",
            "Upgradeable Contract'ta proxy pattern'ı ilk başta kafam karıştı, delegatecall mantığını kavramak zaman aldı",
            "Access Control'de role-based permission sistemi karmaşık geldi, özellikle inheritance ile birlikte kullanınca",
            "Aslında en zor olan görev değil, 5. göreve geldiğimde yorulmuştum, konsantrasyon düşmüştü",
            "İlk görevler bile zordu çünkü Solidity'e yeni başlamıştım, ama zamanla alıştım"
        ]
    },
    "ai_potential": {
        "kısa": [
            "Çok yararlı",
            "Faydalı olabilir",
            "İyi bir araç",
            "Potansiyeli var",
            "Eğitim için ideal"
        ],
        "orta": [
            "AI eğitimde devrim yaratabilir",
            "Kişiselleştirilmiş öğrenme için harika",
            "Teknik konuları öğrenmede çok etkili",
            "Blockchain gibi zor konuları erişilebilir kılıyor",
            "Mentor desteği olmayan öğrenciler için çok değerli",
            "7/24 erişilebilir olması büyük avantaj",
            "Hızlı prototipleme için mükemmel"
        ],
        "detaylı": [
            "AI destekli öğrenme, özellikle benim gibi kendi kendine öğrenen birisi için inanılmaz değerli. İstediğim zaman soru sorabilmek büyük avantaj.",
            "Blockchain eğitiminde AI kullanımı gerçekten çığır açıcı olabilir çünkü bu alan hem hızlı değişiyor hem de kaynak bulmak zor.",
            "Şu anki haliyle bile çok faydalı ama daha interaktif ve pratik odaklı olursa mükemmel olur. Belki bir sandbox entegrasyonu?",
            "AI'ın potansiyeli büyük ama tek başına yeterli değil, insan mentorluğuyla birleştirilirse çok güçlü bir öğrenme deneyimi olur.",
            "Üniversitede böyle bir sistem olsaydı çok daha hızlı öğrenirdim, mevcut eğitim sistemi bu teknolojileri kullanmalı."
        ]
    },
    "suggestions": {
        "kısa": [
            "Daha fazla pratik",
            "Video eklenebilir",
            "İyi sistem",
            "Devam edin",
            "-"
        ],
        "orta": [
            "Daha fazla interaktif alıştırma eklenebilir",
            "Video açıklamalar da olabilir",
            "Zorluk seviyesi ayarlanabilir olmalı",
            "Daha fazla gerçek dünya örneği",
            "Quiz formatında değerlendirmeler eklenebilir",
            "Kod playground entegrasyonu faydalı olur",
            "Progress tracking özelliği eklenebilir"
        ],
        "detaylı": [
            "Remix IDE ile entegrasyon olsa ve yazdığımız kodları direkt test edebilsek çok daha etkili olur, teori ile pratik birleşir.",
            "Her görev sonunda kısa bir quiz olsa öğrenmeyi pekiştirirdik, şu an sadece kod üretimi var ama kavram kontrolü yok.",
            "Farklı zorluk seviyeleri olsa iyi olur, ben competent seviyedeyim ama bazen çok kolay bazen çok zor geldi.",
            "Topluluk özelliği eklenebilir, diğer öğrencilerin çözümlerini görmek ve tartışmak öğretici olurdu.",
            "Mobile uygulama versiyonu olsa yolda giderken bile çalışabilirdim, şu an sadece web'de kullanabiliyorum."
        ]
    }
}


# =============================================================================
# YARDIMCI FONKSİYONLAR
# =============================================================================

def calculate_user_vector(level: str, domain: str, score: float) -> Dict[str, float]:
    """UserVector oluştur (10 boyut)"""
    technical_skill = LEVEL_MAPPING[level]
    domain_knowledge = 0.8 if domain == "technical" else 0.7
    ai_experience = random.uniform(0.1, 0.5)  # Rastgele AI deneyimi
    learning_goal = LEARNING_GOAL_MAPPING[level]
    
    # Nonaka & Takeuchi bilgi türleri
    procedural_knowledge = min(1.0, score * 1.2)
    declarative_knowledge = score
    conditional_knowledge = max(0.3, score - 0.2)
    
    # Bilişsel faktörler
    cognitive_capacity = 0.5 + (score * 0.5)
    pattern_recognition = max(0.3, score - 0.1)
    abstraction_level = score
    
    return {
        "technical_skill": round(technical_skill + random.uniform(-0.05, 0.05), 3),
        "domain_knowledge": round(domain_knowledge + random.uniform(-0.1, 0.1), 3),
        "ai_experience": round(ai_experience, 3),
        "learning_goal": round(learning_goal, 3),
        "procedural_knowledge": round(procedural_knowledge, 3),
        "declarative_knowledge": round(declarative_knowledge, 3),
        "conditional_knowledge": round(conditional_knowledge, 3),
        "cognitive_capacity": round(cognitive_capacity + random.uniform(-0.1, 0.1), 3),
        "pattern_recognition": round(pattern_recognition + random.uniform(-0.05, 0.05), 3),
        "abstraction_level": round(abstraction_level + random.uniform(-0.1, 0.1), 3)
    }


def calculate_similarity_score(user_vec: Dict, persona: Dict) -> float:
    """Benzerlik skoru hesapla (Cosine + Euclidean hybrid)"""
    # Basitleştirilmiş hesaplama
    user_arr = np.array([user_vec["technical_skill"], user_vec["domain_knowledge"], 
                         user_vec["learning_goal"], user_vec["cognitive_capacity"]])
    persona_arr = np.array([persona["technical_depth"], persona["production_readiness"],
                           1 - persona["pedagogical_focus"], persona["modularity"]])
    
    # Cosine similarity
    cos_sim = np.dot(user_arr, persona_arr) / (np.linalg.norm(user_arr) * np.linalg.norm(persona_arr) + 0.001)
    
    # Euclidean similarity
    euclidean = np.linalg.norm(user_arr - persona_arr)
    euclidean_sim = 1 - (euclidean / 2)  # Normalize
    
    return 0.6 * cos_sim + 0.4 * euclidean_sim


def calculate_competency_match(user_vec: Dict, persona: Dict) -> float:
    """ZPD bazlı yetkinlik uyumu hesapla"""
    user_skill = (user_vec["technical_skill"] + user_vec["domain_knowledge"]) / 2
    persona_difficulty = (persona["code_complexity"] + persona["technical_depth"]) / 2
    
    skill_diff = abs(user_skill - persona_difficulty)
    gaussian_match = np.exp(-2 * skill_diff ** 2)
    
    # Alignment
    if user_vec["learning_goal"] > 0.7:
        alignment = persona["pedagogical_focus"]
    else:
        alignment = persona["production_readiness"]
    
    # Knowledge match
    knowledge_match = (0.4 * user_vec["procedural_knowledge"] * persona["modularity"] +
                      0.3 * user_vec["declarative_knowledge"] * persona["verbosity"] +
                      0.3 * user_vec["conditional_knowledge"] * persona["learning_support"])
    
    return 0.5 * gaussian_match + 0.3 * alignment + 0.2 * knowledge_match


def calculate_clt_modifier(user_vec: Dict, persona: Dict, task_complexity: float) -> Tuple[float, Dict]:
    """CLT modifier hesapla"""
    # Intrinsic load
    user_expertise = (0.4 * user_vec["technical_skill"] + 
                     0.3 * user_vec["domain_knowledge"] + 
                     0.3 * user_vec["procedural_knowledge"])
    intrinsic_load = task_complexity * (1 - user_expertise)
    
    # Extraneous load
    extraneous_load = (0.4 * (1 - persona["modularity"]) + 
                      0.3 * max(0, persona["verbosity"] - 0.7) +
                      0.3 * persona["code_complexity"] * 0.5)
    
    # Germane load
    germane_load = (0.35 * persona["learning_support"] +
                   0.30 * persona["pedagogical_focus"] +
                   0.20 * user_vec["cognitive_capacity"] +
                   0.15 * persona.get("example_richness", 0.5))
    
    total_load = intrinsic_load + extraneous_load - germane_load
    productive_load = intrinsic_load + germane_load
    is_optimal = productive_load <= user_vec["cognitive_capacity"] and extraneous_load < 0.3
    
    # Modifier hesapla
    modifier = 1.0
    adjustments = []
    
    if is_optimal:
        modifier += 0.10
        adjustments.append("optimal_zone_bonus")
    
    if germane_load > 0.7:
        modifier += 0.05
        adjustments.append("high_germane_bonus")
    
    if total_load > user_vec["cognitive_capacity"]:
        penalty = min(0.30, (total_load - user_vec["cognitive_capacity"]) * 0.3)
        modifier -= penalty
        adjustments.append(f"overload_penalty_{penalty:.2f}")
    
    if extraneous_load > 0.5:
        modifier -= 0.10
        adjustments.append("high_extraneous_penalty")
    
    clt_analysis = {
        "intrinsic_load": round(intrinsic_load, 3),
        "extraneous_load": round(extraneous_load, 3),
        "germane_load": round(germane_load, 3),
        "total_load": round(total_load, 3),
        "is_in_optimal_zone": is_optimal,
        "adjustments": adjustments
    }
    
    return max(0.7, min(1.15, modifier)), clt_analysis


def calculate_recommendation_score(user_vec: Dict, persona: Dict, 
                                   task_complexity: float, mode: str) -> Dict:
    """MCDA + CLT ile öneri skoru hesapla"""
    S = calculate_similarity_score(user_vec, persona)
    C = calculate_competency_match(user_vec, persona)
    
    # Performance prediction (simplified)
    P = 1 / (1 + np.exp(-(0.3 + 0.4 * user_vec["technical_skill"] + 
                          0.3 * persona["production_readiness"] - 
                          0.2 * task_complexity)))
    
    # Learning trajectory
    L = (1 - np.exp(-2 * 0.5)) * persona["learning_support"] * user_vec["cognitive_capacity"]
    
    # Ağırlıklar
    alpha, beta, gamma, delta = 0.30, 0.35, 0.25, 0.10
    
    if mode == "similarity":
        base_score = alpha * S + beta * C + gamma * P + delta * L
    else:  # complementary
        D = calculate_complementarity(user_vec, persona)
        base_score = alpha * (1 - S) + beta * D + gamma * P + delta * L
    
    # CLT modifier
    clt_modifier, clt_analysis = calculate_clt_modifier(user_vec, persona, task_complexity)
    final_score = base_score * clt_modifier
    
    return {
        "persona_name": persona["name"],
        "mode": mode,
        "base_score": round(base_score, 4),
        "clt_modifier": round(clt_modifier, 4),
        "final_score": round(final_score, 4),
        "components": {
            "S": round(S, 4),
            "C": round(C, 4),
            "P": round(P, 4),
            "L": round(L, 4)
        },
        "clt_analysis": clt_analysis
    }


def calculate_complementarity(user_vec: Dict, persona: Dict) -> float:
    """Tamamlayıcılık skoru hesapla"""
    user_weaknesses = {
        "technical": 1 - user_vec["technical_skill"],
        "domain": 1 - user_vec["domain_knowledge"],
        "procedural": 1 - user_vec["procedural_knowledge"]
    }
    
    persona_strengths = {
        "technical": persona["technical_depth"],
        "domain": persona["pedagogical_focus"],
        "procedural": persona["modularity"]
    }
    
    complementarity = sum(user_weaknesses[k] * persona_strengths[k] 
                         for k in user_weaknesses) / len(user_weaknesses)
    return complementarity


def select_personas(user_vec: Dict, dominant_domain: str) -> Dict:
    """Similar ve Complementary persona seç"""
    # Similar: dominant domain
    similar_candidates = TECHNOLOGY_PERSONAS if dominant_domain == "technical" else EDUCATION_PERSONAS
    
    # Complementary: weak domain
    complementary_candidates = EDUCATION_PERSONAS if dominant_domain == "technical" else TECHNOLOGY_PERSONAS
    
    # En yüksek skorlu persona'ları seç
    similar_scores = [calculate_recommendation_score(user_vec, p, 0.5, "similarity") 
                     for p in similar_candidates]
    similar_best = max(similar_scores, key=lambda x: x["final_score"])
    
    complementary_scores = [calculate_recommendation_score(user_vec, p, 0.5, "complementary") 
                           for p in complementary_candidates]
    complementary_best = max(complementary_scores, key=lambda x: x["final_score"])
    
    return {
        "similar": similar_best,
        "complementary": complementary_best,
        "all_similar_scores": similar_scores,
        "all_complementary_scores": complementary_scores
    }


def calculate_adaptive_decision(task_number: int, learning_goal: float,
                               nasa_tlx_history: List[Dict],
                               similar_count: int, complementary_count: int) -> Dict:
    """Adaptive mod kararı (v2.0 logic)"""
    HIGH_LOAD_THRESHOLD = 40
    
    if task_number == 1:
        # İlk görev: learning_goal'e göre
        if learning_goal > 0.7:
            decision = "Complementary"
            reason = f"learning_goal={learning_goal:.2f} > 0.7, öğrenme odaklı"
        elif learning_goal < 0.3:
            decision = "Similar"
            reason = f"learning_goal={learning_goal:.2f} < 0.3, üretim odaklı"
        else:
            decision = "Similar"
            reason = f"learning_goal={learning_goal:.2f} orta seviye, varsayılan Similar"
    else:
        # Sonraki görevler: NASA-TLX'e göre
        if nasa_tlx_history:
            last_entry = nasa_tlx_history[-1]
            last_score = last_entry["total_cognitive_load"]
            last_ai_type = last_entry["ai_type"]
            
            if last_score > HIGH_LOAD_THRESHOLD:
                # Yoruldu, mod değiştir
                decision = "Complementary" if last_ai_type == "Similar" else "Similar"
                reason = f"NASA-TLX={last_score} > {HIGH_LOAD_THRESHOLD}, mod değiştirildi"
            else:
                # Normal, dengele
                if similar_count < complementary_count:
                    decision = "Similar"
                    reason = f"Denge: Similar({similar_count}) < Complementary({complementary_count})"
                elif complementary_count < similar_count:
                    decision = "Complementary"
                    reason = f"Denge: Complementary({complementary_count}) < Similar({similar_count})"
                else:
                    decision = last_ai_type
                    reason = f"NASA-TLX={last_score} normal, önceki modla devam"
        else:
            decision = "Similar"
            reason = "NASA-TLX verisi yok, varsayılan Similar"
    
    return {
        "task": task_number,
        "decision": decision,
        "reason": reason,
        "learning_goal": learning_goal if task_number == 1 else None,
        "nasa_tlx_trigger": nasa_tlx_history[-1]["total_cognitive_load"] if task_number > 1 and nasa_tlx_history else None
    }


def generate_nasa_tlx(task_complexity: float, ai_match_quality: float,
                     user_level: str, is_mode_switched: bool,
                     task_number: int = 1, personality: Dict = None,
                     ai_type: str = "Similar") -> Dict[str, int]:
    """NASA-TLX yanıtları üret (DUAL-MODE ETKİLİ)"""
    
    if personality is None:
        personality = {"optimism": 0.5, "fatigue_sensitivity": 0.5, "consistency": 0.8}
    
    # Temel yük hesabı
    base_load = task_complexity * 6 + random.uniform(-1, 1)
    
    # Kullanıcı seviyesine göre ayarla
    level_modifier = {"novice": 1.3, "advanced_beginner": 1.1, "competent": 1.0,
                     "proficient": 0.9, "expert": 0.8}[user_level]
    
    # AI uyumu iyi ise yük azalır
    match_modifier = 1.2 - (ai_match_quality * 0.4)
    
    # Mod değişimi olmuşsa adaptasyon için hafif artış
    switch_modifier = 1.1 if is_mode_switched else 1.0
    
    # =================================================================
    # DUAL-MODE ETKİSİ: Similar = düşük yük, Complementary = yüksek yük
    # =================================================================
    # Similar mod: tanıdık, rahat → düşük bilişsel yük
    # Complementary mod: zorlayıcı, yeni → yüksek bilişsel yük
    if ai_type == "Similar":
        mode_load_modifier = 0.85  # %15 daha düşük yük
    else:  # Complementary
        mode_load_modifier = 1.15  # %15 daha yüksek yük
    
    # Seviyeye göre mod etkisi farklılaşır
    # Novice'ler Complementary'de daha çok zorlanır
    # Expert'ler her iki modda da rahat
    if user_level == "novice" and ai_type == "Complementary":
        mode_load_modifier *= 1.1  # Ekstra yük
    elif user_level == "expert":
        mode_load_modifier = 0.95  # Her iki modda da düşük
    
    # =================================================================
    # YORGUNLUK ETKİSİ (Görev 4-6'da birikimli yorgunluk)
    # =================================================================
    fatigue_effect = 0
    if task_number >= 4:
        fatigue_effect = (task_number - 3) * 0.15 * personality["fatigue_sensitivity"]
    
    # =================================================================
    # KİŞİLİK ETKİSİ (Optimistler daha düşük yük bildirir)
    # =================================================================
    personality_modifier = 1.0 - (personality["optimism"] - 0.5) * 0.3
    
    # Tutarlılık: düşük tutarlılık = daha fazla varyans
    variance = (1 - personality["consistency"]) * 2
    
    adjusted_load = base_load * level_modifier * match_modifier * switch_modifier * mode_load_modifier
    adjusted_load = adjusted_load * (1 + fatigue_effect) * personality_modifier
    
    # Her boyut için skor üret
    mental_demand = int(np.clip(adjusted_load + random.uniform(-1 - variance, 2 + variance), 1, 10))
    physical_demand = int(np.clip(random.uniform(1, 4), 1, 10))  # Genelde düşük
    temporal_demand = int(np.clip(adjusted_load * 0.8 + random.uniform(-1, 1 + variance), 1, 10))
    
    # Performance: Optimistler kendini daha başarılı görür
    perf_optimism = personality["optimism"] * 2
    performance = int(np.clip(10 - adjusted_load * 0.6 + perf_optimism + random.uniform(-1, 1), 1, 10))
    
    effort = int(np.clip(adjusted_load * 0.9 + random.uniform(-1, 1 + variance), 1, 10))
    frustration = int(np.clip(adjusted_load * 0.7 + random.uniform(-2, 2 + variance), 1, 10))
    
    total = mental_demand + physical_demand + temporal_demand + performance + effort + frustration
    
    return {
        "mental_demand": mental_demand,
        "physical_demand": physical_demand,
        "temporal_demand": temporal_demand,
        "performance": performance,
        "effort": effort,
        "frustration": frustration,
        "total_cognitive_load": total,
        "fatigue_effect": round(fatigue_effect, 3)
    }


def generate_test_scores(level: str, task_complexity: float, 
                        is_post: bool, pre_score: int = None,
                        task_number: int = 1, personality: Dict = None,
                        previous_gain: float = None,
                        ai_type: str = "Similar") -> int:
    """Pre/Post test skorları üret (DUAL-MODE ETKİLİ)"""
    
    if personality is None:
        personality = {"is_outlier": False, "optimism": 0.5}
    
    level_base = {"novice": 40, "advanced_beginner": 50, "competent": 60,
                 "proficient": 70, "expert": 80}[level]
    
    complexity_penalty = task_complexity * 15
    base = level_base - complexity_penalty
    
    if is_post and pre_score:
        # =================================================================
        # DUAL-MODE ETKİSİ: Complementary = yüksek öğrenme, Similar = düşük
        # =================================================================
        # Similar mod: rahat ama daha az gelişim
        # Complementary mod: zorlu ama daha fazla öğrenme
        
        if ai_type == "Complementary":
            base_gain = random.uniform(10, 22)  # Daha yüksek kazanım
            
            # Seviyeye göre farklılaşma
            if level == "novice":
                base_gain *= 1.15  # Novice'ler en çok yararlanır
            elif level == "expert":
                base_gain *= 1.10  # Expert'ler yeni perspektif kazanır
            elif level in ["advanced_beginner", "competent"]:
                base_gain *= 0.95  # Orta seviyelerde biraz daha az
                
        else:  # Similar
            base_gain = random.uniform(4, 12)  # Daha düşük kazanım
            
            # Similar mod için seviye etkisi
            if level in ["advanced_beginner", "competent"]:
                base_gain *= 1.1  # Bu seviyeler Similar'dan daha iyi yararlanır
            elif level == "novice":
                base_gain *= 0.9  # Novice'ler için yeterli değil
        
        learning_gain = base_gain
        
        # =================================================================
        # GERÇEKÇİ ÖĞRENME KALIPLARI
        # =================================================================
        
        # %12 ihtimalle plato (öğrenme yok)
        if random.random() < 0.12:
            learning_gain = random.uniform(-2, 4)  # Minimal değişim
        
        # %6 ihtimalle gerileme (kafa karışıklığı - Complementary'de daha fazla)
        elif random.random() < (0.08 if ai_type == "Complementary" else 0.04):
            learning_gain = random.uniform(-6, -1)  # Negatif
        
        # %8 ihtimalle sıçrama (eureka anı - Complementary'de daha fazla)
        elif random.random() < (0.12 if ai_type == "Complementary" else 0.06):
            learning_gain = random.uniform(22, 38)  # Yüksek kazanım
        
        # Önceki kazanıma göre ayarla (ardışık yüksek kazanım zor)
        if previous_gain and previous_gain > 18:
            learning_gain *= 0.75
        
        # Yorgunluk etkisi (geç görevlerde daha az öğrenme)
        if task_number >= 5:
            learning_gain *= 0.85
        
        score = pre_score + learning_gain
    else:
        score = base + random.uniform(-10, 15)
    
    # =================================================================
    # OUTLIER ETKİSİ
    # =================================================================
    if personality.get("is_outlier", False):
        if random.random() < 0.5:
            score = score * 1.35
        else:
            score = score * 0.65
    
    return int(np.clip(score, 0, 100))


def generate_ai_evaluation(ai_match_quality: float, is_complementary: bool,
                          personality: Dict = None, task_number: int = 1) -> Dict[str, Any]:
    """AI değerlendirme yanıtları üret (Kişilik ve tutarlılık etkili)"""
    
    if personality is None:
        personality = {"optimism": 0.5, "consistency": 0.8, "writing_style": "orta"}
    
    # Optimistler daha yüksek puan verir
    optimism_bonus = (personality["optimism"] - 0.5) * 2
    base = 5 + ai_match_quality * 3 + optimism_bonus
    
    # Tutarlılık: düşük tutarlılık = daha fazla varyans
    variance = (1 - personality["consistency"]) * 2
    
    # Complementary genelde daha öğretici ama daha zorlu
    if is_complementary:
        educational_bonus = 1
        understandability_penalty = 0.5
    else:
        educational_bonus = 0
        understandability_penalty = 0
    
    # Yorgunluk etkisi (geç görevlerde biraz daha düşük puanlar)
    fatigue_penalty = max(0, (task_number - 4) * 0.3) if task_number > 4 else 0
    
    writing_style = personality.get("writing_style", "orta")
    
    return {
        "code_understandability": int(np.clip(base - understandability_penalty - fatigue_penalty + random.uniform(-1 - variance, 1 + variance), 1, 10)),
        "explanation_quality": int(np.clip(base - fatigue_penalty + random.uniform(-1 - variance, 1 + variance), 1, 10)),
        "educational_value": int(np.clip(base + educational_bonus - fatigue_penalty + random.uniform(-1, 1 + variance), 1, 10)),
        "perceived_code_quality": int(np.clip(base - fatigue_penalty + random.uniform(-1, 1.5 + variance), 1, 10)),
        "perceived_security": int(np.clip(base - fatigue_penalty + random.uniform(-1.5, 1 + variance), 1, 10)),
        "best_aspect": random.choice(OPEN_ENDED_TEMPLATES["best_aspect"][writing_style]),
        "improvement_needed": random.choice(OPEN_ENDED_TEMPLATES["improvement_needed"][writing_style])
    }


def generate_final_evaluation(similar_count: int, complementary_count: int,
                             avg_similar_load: float, avg_complementary_load: float,
                             learning_goal: float, personality: Dict = None,
                             similar_avg_gain: float = 8, comp_avg_gain: float = 14) -> Dict[str, Any]:
    """Final değerlendirme üret (DUAL-MODE FARKINI YANSITIR)"""
    
    if personality is None:
        personality = {"optimism": 0.5, "writing_style": "orta"}
    
    optimism = personality["optimism"]
    writing_style = personality.get("writing_style", "orta")
    
    # =================================================================
    # DUAL-MODE TERCİH MANTĞI
    # Similar: rahat ama az öğrenme → rahat çalışma tercih edenler seçer
    # Complementary: zor ama çok öğrenme → gelişim isteyenler seçer
    # Her ikisi de: dengeli bakış açısı
    # =================================================================
    
    # Öğrenme odaklı kullanıcılar Complementary tercih eder
    if learning_goal > 0.65:
        preferred_weights = [0.20, 0.50, 0.30]  # Similar, Complementary, Her ikisi
        preferred = random.choices(["Similar", "Complementary", "Her ikisi de"], weights=preferred_weights)[0]
        if preferred == "Complementary":
            reason = "Daha zorlayıcıydı ama çok şey öğrendim, gelişimim için daha faydalıydı"
        elif preferred == "Similar":
            reason = "Rahat çalışabildim, stres yaşamadım"
        else:
            reason = "Her ikisinin de avantajları vardı - Similar rahat, Complementary öğretici"
    
    # Üretim odaklı kullanıcılar Similar tercih eder
    elif learning_goal < 0.35:
        preferred_weights = [0.55, 0.15, 0.30]
        preferred = random.choices(["Similar", "Complementary", "Her ikisi de"], weights=preferred_weights)[0]
        if preferred == "Similar":
            reason = "Hızlı ve verimli çalışabildim, anlaşılır kodlar üretti"
        elif preferred == "Complementary":
            reason = "Zorlu olsa da yeni teknikler öğretti"
        else:
            reason = "Her ikisi de farklı durumlarda işe yarıyor"
    
    # Dengeli kullanıcılar "Her ikisi de" tercih eder
    else:
        preferred_weights = [0.30, 0.30, 0.40]
        preferred = random.choices(["Similar", "Complementary", "Her ikisi de"], weights=preferred_weights)[0]
        if preferred == "Her ikisi de":
            reason = "Similar rahat çalışma, Complementary derin öğrenme sağladı - ikisi de değerli"
        elif preferred == "Similar":
            reason = "Daha rahat hissettim, zorlanmadan ilerleyebildim"
        else:
            reason = "Daha fazla öğrendim, zorluk beni geliştirdi"
    
    # Öğrenme için hangisi daha iyi - net olarak Complementary
    # (Çünkü veriler bunu gösterecek)
    if comp_avg_gain > similar_avg_gain + 3:
        learning_better = "Complementary"
    elif similar_avg_gain > comp_avg_gain + 3:
        learning_better = "Similar"
    else:
        learning_better = random.choice(["Complementary", "Eşit"])  # Genelde Complementary
    
    # Hız için Similar daha iyi (düşük bilişsel yük = hızlı ilerleme)
    speed_better = random.choices(["Similar", "Complementary", "Eşit"], weights=[0.60, 0.15, 0.25])[0]
    
    # Optimistler daha yüksek Likert puanı verir
    likert_bonus = (optimism - 0.5) * 1.5
    
    # Blockchain görüş değişimi (optimistler daha pozitif)
    view_options = ["Çok olumlu değişti", "Olumlu değişti", "Biraz değişti", "Değişmedi", "Olumsuz etkiledi"]
    view_weights = [0.25 + optimism * 0.2, 0.35, 0.25, 0.10, 0.05 - optimism * 0.05]
    view_weights = [max(0.01, w) for w in view_weights]  # Negatif olmasın
    
    # Tavsiye (optimistler daha olumlu)
    recommend_options = ["Kesinlikle evet", "Evet", "Muhtemelen", "Belki", "Kararsızım", "Hayır"]
    recommend_weights = [0.30 + optimism * 0.2, 0.35, 0.15, 0.12, 0.05, 0.03 - optimism * 0.03]
    recommend_weights = [max(0.01, w) for w in recommend_weights]
    
    return {
        "preferred_ai": preferred,
        "preferred_ai_reason": reason,
        "learning_better_ai": learning_better,
        "speed_better_ai": speed_better,
        "comfort_similar": int(np.clip(4 - (avg_similar_load - 30) / 10 + likert_bonus + random.uniform(-0.5, 0.5), 1, 5)),
        "development_complementary": int(np.clip(3.5 + likert_bonus + random.uniform(-0.5, 1), 1, 5)),
        "clarity_similar": int(np.clip(3.8 + likert_bonus + random.uniform(-0.5, 0.5), 1, 5)),
        "quality_complementary": int(np.clip(3.5 + likert_bonus + random.uniform(-0.5, 1), 1, 5)),
        "hybrid_ideal": int(np.clip(4 + likert_bonus + random.uniform(-0.5, 0.5), 1, 5)),
        "blockchain_view_change": random.choices(view_options, weights=view_weights)[0],
        "ai_learning_rating": int(np.clip(7 + likert_bonus * 2 + random.uniform(-1.5, 1.5), 1, 10)),
        "would_recommend": random.choices(recommend_options, weights=recommend_weights)[0],
        "hardest_task": random.choice(OPEN_ENDED_TEMPLATES["hardest_task"][writing_style]),
        "ai_potential": random.choice(OPEN_ENDED_TEMPLATES["ai_potential"][writing_style]),
        "suggestions": random.choice(OPEN_ENDED_TEMPLATES["suggestions"][writing_style]),
        "blockchain_education_view": random.choice([
            "AI destekli blockchain eğitimi çok etkili olabilir",
            "Bu tür sistemler blockchain öğrenimini demokratikleştirir",
            "Potansiyeli büyük, geliştirmeye devam edilmeli",
            "İyi bir başlangıç noktası, ama tek başına yeterli değil",
            "Eğitim teknolojilerinin geleceği bu yönde"
        ])
    }


# =============================================================================
# ANA VERİ ÜRETİM FONKSİYONU
# =============================================================================

def generate_participant_data(participant_id: int, level: str) -> Dict[str, Any]:
    """Tek bir katılımcı için tam veri seti üret"""
    participant_uuid = str(uuid.uuid4())
    
    # =================================================================
    # KİŞİLİK PROFİLİ (Her katılımcı için tutarlı davranış kalıbı)
    # =================================================================
    personality = {
        "optimism": random.gauss(0.5, 0.2),      # Puanlama eğilimi (yüksek=cömert)
        "consistency": random.uniform(0.6, 1.0), # Tutarlılık (düşük=değişken)
        "fatigue_sensitivity": random.uniform(0.3, 1.0),  # Yorgunluk duyarlılığı
        "is_outlier": random.random() < 0.05,    # %5 outlier
        "completes_study": random.random() > 0.08,  # %8 tamamlamaz
        "writing_style": random.choice(["kısa", "orta", "detaylı"])
    }
    personality["optimism"] = np.clip(personality["optimism"], 0.1, 0.9)
    
    # =================================================================
    # DEMOGRAFİK BİLGİLER (Seviyeye göre korelasyonlu)
    # =================================================================
    # Yaş: Expert'ler daha yaşlı, Novice'ler daha genç
    age_ranges = {
        "novice": (20, 28),
        "advanced_beginner": (22, 35),
        "competent": (25, 45),
        "proficient": (30, 50),
        "expert": (35, 55)
    }
    age = random.randint(*age_ranges[level])
    
    # Eğitim: Expert'lerde yüksek lisans/doktora daha olası
    education_weights_by_level = {
        "novice": [0.60, 0.15, 0.02, 0.15, 0.08],           # Lisans ağırlıklı
        "advanced_beginner": [0.55, 0.25, 0.05, 0.08, 0.07],
        "competent": [0.45, 0.35, 0.12, 0.04, 0.04],
        "proficient": [0.30, 0.45, 0.20, 0.02, 0.03],
        "expert": [0.15, 0.40, 0.42, 0.01, 0.02]            # Doktora ağırlıklı
    }
    
    gender = random.choices(DEMOGRAPHICS["genders"], weights=DEMOGRAPHICS["gender_weights"])[0]
    education = random.choices(DEMOGRAPHICS["education"], weights=education_weights_by_level[level])[0]
    work_field = random.choices(DEMOGRAPHICS["work_fields"], weights=DEMOGRAPHICS["work_field_weights"])[0]
    
    # Yetkinlik skorları (Likert 1-5 → 0-100)
    level_likert_ranges = {
        "novice": (1.0, 1.8),
        "advanced_beginner": (1.9, 2.8),
        "competent": (2.9, 3.8),
        "proficient": (3.9, 4.5),
        "expert": (4.6, 5.0)
    }
    
    tech_likert = random.uniform(*level_likert_ranges[level])
    edu_likert = random.uniform(*level_likert_ranges.get(
        random.choice(["novice", "advanced_beginner", level]), (2.0, 3.5)))
    
    technical_score = int((tech_likert - 1) / 4 * 100)
    educational_score = int((edu_likert - 1) / 4 * 100)
    score = (technical_score + educational_score) / 200
    
    # Domain belirleme
    dominant_domain = "technical" if technical_score >= educational_score else "educational"
    weak_domain = "educational" if dominant_domain == "technical" else "technical"
    
    # UserVector oluştur
    user_vector = calculate_user_vector(level, dominant_domain, score)
    learning_goal = user_vector["learning_goal"]
    
    # Persona seçimi
    persona_selection = select_personas(user_vector, dominant_domain)
    similar_persona = persona_selection["similar"]["persona_name"]
    complementary_persona = persona_selection["complementary"]["persona_name"]
    
    # =================================================================
    # GÖREV VERİLERİ (Kişilik etkili, tamamlanmamış katılımcılar dahil)
    # =================================================================
    tasks_data = []
    nasa_tlx_history = []
    adaptive_decisions = []
    similar_count = 0
    complementary_count = 0
    previous_learning_gain = None
    
    # Tamamlanmamış katılımcılar için: rastgele bir görevde bırak
    if not personality["completes_study"]:
        dropout_task = random.randint(2, 5)  # 2-5 arasında bırakır
    else:
        dropout_task = 7  # Tamamlar
    
    for task in TASKS:
        task_number = task["id"]
        
        # Dropout kontrolü
        if task_number > dropout_task:
            break  # Bu görevden sonra bıraktı
        
        # Adaptive karar
        decision = calculate_adaptive_decision(
            task_number, learning_goal, nasa_tlx_history,
            similar_count, complementary_count
        )
        adaptive_decisions.append(decision)
        
        assigned_ai_type = decision["decision"]
        assigned_persona = similar_persona if assigned_ai_type == "Similar" else complementary_persona
        
        # Sayaçları güncelle
        if assigned_ai_type == "Similar":
            similar_count += 1
        else:
            complementary_count += 1
        
        # AI match quality hesapla
        current_persona = next((p for p in TECHNOLOGY_PERSONAS + EDUCATION_PERSONAS 
                               if p["name"] == assigned_persona), TECHNOLOGY_PERSONAS[2])
        ai_match_quality = calculate_similarity_score(user_vector, current_persona)
        
        # Mod değişimi oldu mu?
        is_mode_switched = (task_number > 1 and 
                          adaptive_decisions[-2]["decision"] != assigned_ai_type)
        
        # Pre-test (kişilik etkili)
        pre_score = generate_test_scores(level, task["complexity"], False,
                                        task_number=task_number, personality=personality,
                                        ai_type=assigned_ai_type)
        
        # Post-test (DUAL-MODE ETKİLİ: Complementary daha yüksek kazanım)
        post_score = generate_test_scores(level, task["complexity"], True, pre_score,
                                         task_number=task_number, personality=personality,
                                         previous_gain=previous_learning_gain,
                                         ai_type=assigned_ai_type)
        previous_learning_gain = post_score - pre_score
        
        # NASA-TLX (DUAL-MODE ETKİLİ: Similar daha düşük yük)
        nasa_tlx = generate_nasa_tlx(task["complexity"], ai_match_quality, 
                                     level, is_mode_switched,
                                     task_number=task_number, personality=personality,
                                     ai_type=assigned_ai_type)
        nasa_tlx_history.append({
            "task": task_number,
            "ai_type": assigned_ai_type,
            "persona": assigned_persona,
            "total_cognitive_load": nasa_tlx["total_cognitive_load"],
            **nasa_tlx
        })
        
        # AI değerlendirmesi (kişilik etkili)
        ai_evaluation = generate_ai_evaluation(
            ai_match_quality, assigned_ai_type == "Complementary",
            personality=personality, task_number=task_number
        )
        
        # Task comparison (kişilik bazlı zorluk algısı)
        other_ai = "Complementary" if assigned_ai_type == "Similar" else "Similar"
        
        # Zorluk algısı: yorgunluk + kişilik etkili
        difficulty_options = ["Çok Kolay", "Kolay", "Orta", "Zor", "Çok Zor"]
        base_difficulty_idx = int(task["complexity"] * 4)  # 0-4
        
        # Yorgunluk arttıkça daha zor algılanır
        if task_number >= 4:
            base_difficulty_idx = min(4, base_difficulty_idx + 1)
        
        # Optimistler daha kolay algılar
        if personality["optimism"] > 0.6:
            base_difficulty_idx = max(0, base_difficulty_idx - 1)
        elif personality["optimism"] < 0.4:
            base_difficulty_idx = min(4, base_difficulty_idx + 1)
        
        # Biraz rastgelelik ekle
        base_difficulty_idx = max(0, min(4, base_difficulty_idx + random.choice([-1, 0, 0, 1])))
        
        task_comparison = {
            "used_ai_type": assigned_ai_type,
            "other_ai_type": other_ai,
            "suitability_choice": random.choice([assigned_ai_type, other_ai, "Eşit"]) if task_number > 1 else None,
            "reason": "Bu görev için daha uygun buldum" if task_number > 1 else "",
            "difficulty_rating": difficulty_options[base_difficulty_idx],
            "has_comparison": task_number > 1
        }
        
        # Generated code (simüle - outlier etkisi)
        code_quality_base = 70 if not personality["is_outlier"] else random.choice([40, 90])
        generated_code = {
            "language": "Solidity",
            "prompt_used": f"Task {task_number}: {task['name']} - {task['topic']}",
            "ai_persona": assigned_persona,
            "generation_time_seconds": round(random.uniform(5, 30), 2),
            "functionality_score": int(np.clip(code_quality_base * 0.3 + random.uniform(-5, 5), 0, 30)),
            "security_score": int(np.clip(code_quality_base * 0.25 + random.uniform(-5, 5), 0, 25)),
            "gas_optimization_score": int(np.clip(code_quality_base * 0.25 + random.uniform(-5, 5), 0, 25)),
            "code_quality_score": int(np.clip(code_quality_base * 0.2 + random.uniform(-4, 4), 0, 20)),
        }
        generated_code["total_score"] = (generated_code["functionality_score"] + 
                                         generated_code["security_score"] +
                                         generated_code["gas_optimization_score"] +
                                         generated_code["code_quality_score"])
        
        # Süre: kişilik ve görev zorluğuna bağlı
        base_duration = 15 + task["complexity"] * 20
        if personality["optimism"] < 0.4:  # Karamsarlar daha uzun sürede bitirir
            base_duration *= 1.2
        duration = int(base_duration + random.uniform(-5, 10))
        
        task_data = {
            "task_number": task_number,
            "task_name": task["name"],
            "task_complexity": task["complexity"],
            "assigned_ai_type": assigned_ai_type,
            "assigned_persona": assigned_persona,
            "adaptive_decision": decision,
            "duration_minutes": duration,
            "pre_test": {
                "score": pre_score,
                "answers": {f"q{i}": f"Answer {i}" for i in range(1, 4)}
            },
            "post_test": {
                "score": post_score,
                "learning_gain": post_score - pre_score,
                "answers": {f"q{i}": f"Answer {i}" for i in range(1, 6)}
            },
            "nasa_tlx": nasa_tlx,
            "ai_evaluation": ai_evaluation,
            "task_comparison": task_comparison,
            "generated_code": generated_code
        }
        
        tasks_data.append(task_data)
    
    # =================================================================
    # FİNAL DEĞERLENDİRME (Sadece tamamlayanlar)
    # =================================================================
    is_completed = personality["completes_study"] and len(tasks_data) == 6
    
    avg_similar_load = np.mean([t["nasa_tlx"]["total_cognitive_load"] 
                               for t in tasks_data if t["assigned_ai_type"] == "Similar"]) if similar_count > 0 else 30
    avg_complementary_load = np.mean([t["nasa_tlx"]["total_cognitive_load"] 
                                     for t in tasks_data if t["assigned_ai_type"] == "Complementary"]) if complementary_count > 0 else 30
    
    # Ortalama öğrenme kazanımları (mod bazlı)
    similar_gains = [t["post_test"]["learning_gain"] for t in tasks_data if t["assigned_ai_type"] == "Similar"]
    comp_gains = [t["post_test"]["learning_gain"] for t in tasks_data if t["assigned_ai_type"] == "Complementary"]
    similar_avg_gain = np.mean(similar_gains) if similar_gains else 8
    comp_avg_gain = np.mean(comp_gains) if comp_gains else 14
    
    # Final değerlendirme: sadece tamamlayanlar doldurur
    if is_completed:
        final_evaluation = generate_final_evaluation(
            similar_count, complementary_count,
            avg_similar_load, avg_complementary_load,
            learning_goal, personality=personality,
            similar_avg_gain=similar_avg_gain, comp_avg_gain=comp_avg_gain
        )
    else:
        final_evaluation = None  # Tamamlamadı
    
    # Toplam süre
    total_duration = sum(t["duration_minutes"] for t in tasks_data) + random.randint(10, 30)
    
    # Dropout reason (tamamlamayanlara)
    dropout_reasons = [
        "Zaman yetersizliği",
        "Teknik sorun yaşadım",
        "Görevler çok zordu",
        "Kişisel nedenler",
        "İnternet bağlantısı kesildi",
        None  # Belirtmedi
    ]
    
    return {
        "participant_id": participant_id,
        "uuid": participant_uuid,
        "created_at": (datetime.now() - timedelta(days=random.randint(1, 60))).isoformat(),
        
        "demographics": {
            "age": age,
            "gender": gender,
            "education": education,
            "work_field": work_field
        },
        
        "personality_profile": {  # YENİ: Kişilik profili (analiz için)
            "optimism": round(personality["optimism"], 3),
            "consistency": round(personality["consistency"], 3),
            "fatigue_sensitivity": round(personality["fatigue_sensitivity"], 3),
            "writing_style": personality["writing_style"],
            "is_outlier": personality["is_outlier"]
        },
        
        "competency_profile": {
            "technical_score": technical_score,
            "educational_score": educational_score,
            "technical_level": level,
            "educational_level": random.choice(["novice", "advanced_beginner", "competent"]),
            "dominant_domain": dominant_domain,
            "weak_domain": weak_domain,
            "overall_score": (technical_score + educational_score) / 2
        },
        
        "user_vector": user_vector,
        
        "persona_selection": {
            "similar_persona": similar_persona,
            "similar_score": persona_selection["similar"]["final_score"],
            "similar_clt_analysis": persona_selection["similar"]["clt_analysis"],
            "complementary_persona": complementary_persona,
            "complementary_score": persona_selection["complementary"]["final_score"],
            "complementary_clt_analysis": persona_selection["complementary"]["clt_analysis"]
        },
        
        "adaptive_data": {
            "mode": "adaptive",
            "similar_count": similar_count,
            "complementary_count": complementary_count,
            "nasa_tlx_history": nasa_tlx_history,
            "adaptive_decisions": adaptive_decisions
        },
        
        "tasks": tasks_data,
        
        "final_evaluation": final_evaluation,
        
        "summary": {
            "total_duration_minutes": total_duration,
            "completed": is_completed,
            "tasks_completed": len(tasks_data),
            "dropout_reason": random.choice(dropout_reasons) if not is_completed else None,
            "avg_pre_test_score": round(np.mean([t["pre_test"]["score"] for t in tasks_data]), 2) if tasks_data else None,
            "avg_post_test_score": round(np.mean([t["post_test"]["score"] for t in tasks_data]), 2) if tasks_data else None,
            "avg_learning_gain": round(np.mean([t["post_test"]["learning_gain"] for t in tasks_data]), 2) if tasks_data else None,
            "avg_cognitive_load": round(np.mean([t["nasa_tlx"]["total_cognitive_load"] for t in tasks_data]), 2) if tasks_data else None,
            "high_load_count": sum(1 for t in tasks_data if t["nasa_tlx"]["total_cognitive_load"] > 40),
            "mode_switches": sum(1 for i, d in enumerate(adaptive_decisions) 
                                if i > 0 and d["decision"] != adaptive_decisions[i-1]["decision"])
        }
    }


def generate_all_participants(output_dir: str = None) -> List[Dict]:
    """150 katılımcı için veri üret"""
    if output_dir is None:
        output_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 
                                  "data", "synthetic")
    
    os.makedirs(output_dir, exist_ok=True)
    
    all_participants = []
    participant_id = 1
    
    print("=" * 60)
    print("PIDL Sentetik Veri Üretici v2.1 (Realistic)")
    print("=" * 60)
    print("Özellikler:")
    print("  - Kişilik profilleri (optimism, consistency, fatigue)")
    print("  - Yaş-seviye korelasyonu")
    print("  - %8 tamamlanmamış katılımcı")
    print("  - %5 outlier")
    print("  - Yorgunluk etkisi (görev 4-6)")
    print("  - Öğrenme platoları ve gerilemeler")
    
    for level, count in PARTICIPANT_DISTRIBUTION.items():
        print(f"\n[{level.upper()}] {count} katılımcı üretiliyor...")
        
        for i in range(count):
            participant = generate_participant_data(participant_id, level)
            all_participants.append(participant)
            
            # Bireysel JSON dosyası
            individual_path = os.path.join(output_dir, f"participant_{participant_id:03d}_{level}.json")
            with open(individual_path, 'w', encoding='utf-8') as f:
                json.dump(participant, f, ensure_ascii=False, indent=2)
            
            participant_id += 1
            
            if (i + 1) % 10 == 0:
                print(f"  - {i + 1}/{count} tamamlandı")
    
    # Tüm veriler tek dosyada
    all_data_path = os.path.join(output_dir, "all_participants.json")
    with open(all_data_path, 'w', encoding='utf-8') as f:
        json.dump(all_participants, f, ensure_ascii=False, indent=2)
    
    # Özet istatistikler
    summary_stats = generate_summary_statistics(all_participants)
    summary_path = os.path.join(output_dir, "summary_statistics.json")
    with open(summary_path, 'w', encoding='utf-8') as f:
        json.dump(summary_stats, f, ensure_ascii=False, indent=2)
    
    print("\n" + "=" * 60)
    print("VERİ ÜRETİMİ TAMAMLANDI")
    print("=" * 60)
    print(f"\nToplam katılımcı: {len(all_participants)}")
    print(f"Çıktı dizini: {output_dir}")
    print(f"\nDosyalar:")
    print(f"  - all_participants.json (tüm veriler)")
    print(f"  - summary_statistics.json (özet istatistikler)")
    print(f"  - participant_XXX_level.json (bireysel dosyalar)")
    
    return all_participants


def generate_summary_statistics(participants: List[Dict]) -> Dict:
    """Özet istatistikler üret (Gerçekçi metriklerle)"""
    stats = {
        "total_participants": len(participants),
        "generation_date": datetime.now().isoformat(),
        "version": "2.1 - Realistic",
        
        "by_level": {},
        "demographics_summary": {
            "age": {"min": 100, "max": 0, "mean": 0},
            "gender_distribution": {},
            "education_distribution": {},
            "work_field_distribution": {}
        },
        "completion_summary": {  # YENİ
            "completed": 0,
            "incomplete": 0,
            "completion_rate": 0,
            "dropout_by_task": {2: 0, 3: 0, 4: 0, 5: 0}
        },
        "personality_summary": {  # YENİ
            "avg_optimism": 0,
            "avg_consistency": 0,
            "outlier_count": 0,
            "writing_style_distribution": {}
        },
        "performance_summary": {
            "avg_pre_test": 0,
            "avg_post_test": 0,
            "avg_learning_gain": 0,
            "avg_cognitive_load": 0,
            "learning_gain_std": 0  # YENİ
        },
        "adaptive_summary": {
            "total_mode_switches": 0,
            "avg_similar_count": 0,
            "avg_complementary_count": 0,
            "high_load_triggers": 0
        }
    }
    
    ages = []
    pre_tests = []
    post_tests = []
    learning_gains = []
    cognitive_loads = []
    mode_switches = []
    similar_counts = []
    complementary_counts = []
    optimisms = []
    consistencies = []
    
    for p in participants:
        level = p["competency_profile"]["technical_level"]
        if level not in stats["by_level"]:
            stats["by_level"][level] = {"count": 0, "avg_score": 0, "scores": [], "completed": 0}
        stats["by_level"][level]["count"] += 1
        stats["by_level"][level]["scores"].append(p["competency_profile"]["overall_score"])
        
        # Completion tracking
        if p["summary"]["completed"]:
            stats["completion_summary"]["completed"] += 1
            stats["by_level"][level]["completed"] += 1
        else:
            stats["completion_summary"]["incomplete"] += 1
            tasks_done = p["summary"]["tasks_completed"]
            if tasks_done in stats["completion_summary"]["dropout_by_task"]:
                stats["completion_summary"]["dropout_by_task"][tasks_done] += 1
        
        ages.append(p["demographics"]["age"])
        
        gender = p["demographics"]["gender"]
        stats["demographics_summary"]["gender_distribution"][gender] = \
            stats["demographics_summary"]["gender_distribution"].get(gender, 0) + 1
        
        edu = p["demographics"]["education"]
        stats["demographics_summary"]["education_distribution"][edu] = \
            stats["demographics_summary"]["education_distribution"].get(edu, 0) + 1
        
        work = p["demographics"]["work_field"]
        stats["demographics_summary"]["work_field_distribution"][work] = \
            stats["demographics_summary"]["work_field_distribution"].get(work, 0) + 1
        
        # Personality
        if "personality_profile" in p:
            optimisms.append(p["personality_profile"]["optimism"])
            consistencies.append(p["personality_profile"]["consistency"])
            if p["personality_profile"]["is_outlier"]:
                stats["personality_summary"]["outlier_count"] += 1
            
            style = p["personality_profile"]["writing_style"]
            stats["personality_summary"]["writing_style_distribution"][style] = \
                stats["personality_summary"]["writing_style_distribution"].get(style, 0) + 1
        
        # Performance (sadece veri olanlar)
        if p["summary"]["avg_pre_test_score"] is not None:
            pre_tests.append(p["summary"]["avg_pre_test_score"])
            post_tests.append(p["summary"]["avg_post_test_score"])
            learning_gains.append(p["summary"]["avg_learning_gain"])
            cognitive_loads.append(p["summary"]["avg_cognitive_load"])
        
        mode_switches.append(p["summary"]["mode_switches"])
        similar_counts.append(p["adaptive_data"]["similar_count"])
        complementary_counts.append(p["adaptive_data"]["complementary_count"])
    
    # Level averages
    for level in stats["by_level"]:
        scores = stats["by_level"][level]["scores"]
        stats["by_level"][level]["avg_score"] = round(np.mean(scores), 2)
        stats["by_level"][level]["completion_rate"] = round(
            stats["by_level"][level]["completed"] / stats["by_level"][level]["count"] * 100, 1
        )
        del stats["by_level"][level]["scores"]
    
    # Demographics
    stats["demographics_summary"]["age"]["min"] = min(ages)
    stats["demographics_summary"]["age"]["max"] = max(ages)
    stats["demographics_summary"]["age"]["mean"] = round(np.mean(ages), 1)
    
    # Completion
    stats["completion_summary"]["completion_rate"] = round(
        stats["completion_summary"]["completed"] / len(participants) * 100, 1
    )
    
    # Personality
    if optimisms:
        stats["personality_summary"]["avg_optimism"] = round(np.mean(optimisms), 3)
        stats["personality_summary"]["avg_consistency"] = round(np.mean(consistencies), 3)
    
    # Performance
    if pre_tests:
        stats["performance_summary"]["avg_pre_test"] = round(np.mean(pre_tests), 2)
        stats["performance_summary"]["avg_post_test"] = round(np.mean(post_tests), 2)
        stats["performance_summary"]["avg_learning_gain"] = round(np.mean(learning_gains), 2)
        stats["performance_summary"]["learning_gain_std"] = round(np.std(learning_gains), 2)
        stats["performance_summary"]["avg_cognitive_load"] = round(np.mean(cognitive_loads), 2)
    
    # Adaptive
    stats["adaptive_summary"]["total_mode_switches"] = sum(mode_switches)
    stats["adaptive_summary"]["avg_mode_switches"] = round(np.mean(mode_switches), 2)
    stats["adaptive_summary"]["avg_similar_count"] = round(np.mean(similar_counts), 2)
    stats["adaptive_summary"]["avg_complementary_count"] = round(np.mean(complementary_counts), 2)
    stats["adaptive_summary"]["high_load_triggers"] = sum(p["summary"]["high_load_count"] for p in participants)
    
    return stats


# =============================================================================
# ÇALIŞTIRMA
# =============================================================================

if __name__ == "__main__":
    print("\n🚀 Sentetik veri üretimi başlatılıyor...\n")
    
    # Seed for reproducibility
    random.seed(42)
    np.random.seed(42)
    
    participants = generate_all_participants()
    
    print("\n✅ İşlem tamamlandı!")
