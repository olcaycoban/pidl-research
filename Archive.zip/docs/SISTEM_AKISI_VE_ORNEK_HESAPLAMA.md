# PIDL Araştırma Sistemi – Kullanıcı Bilgisi Girişinden Sonra Ne Oluyor?

Bu belge:
1. Kullanıcı bilgilerini girdikten sonra **tam akışı** adım adım anlatır.
2. **Hangi teori nerede** kullanılıyor tek tek listeler.
3. **Örnek bir veri** üzerinden tüm parametrelerin nasıl hesaplandığını gösterir.
4. Sistemin **adaptifliğini** ve **dual mode** yapısını açıklar.

---

## 1. Kullanıcı Bilgisi Girişinden Sonra Genel Akış

Kullanıcı "Yetkinliğimi Değerlendir" butonuna bastığı anda şu sıra işler:

```
[Form cevapları] 
    → CompetencyAssessment.create_profile()     → CompetencyProfile (dual domain)
    → get_persona_recommendations_from_profile() 
        → (Matematiksel Engine) RecommendationEngine
            → create_user_vector()              → UserVector
            → calculate_recommendation_score(..., mode="similarity")   → Similar persona
            → calculate_recommendation_score(..., mode="complementary") → Complementary persona
    → Session state: similar_persona, complementary_persona
    → DataLogger.create_participant()
    → Ekranda: skorlar, 2 persona kartı, "Görevlere Başla"
```

Yani: **Form → Profil → User Vector → Persona skorları → Similar + Complementary seçimi → Görevlere atama.**

---

## 2. Hangi Teori Nerede Kullanılıyor?

| Bileşen | Teori / Kaynak | Kullanım Yeri |
|--------|----------------|----------------|
| **Yetkinlik seviyeleri** | **Dreyfus Model of Skill Acquisition** (1980) | `competency_assessment.py`: LEVELS (novice → expert), `determine_level()`, persona vektörleri (Dreyfus seviyesine göre kod özellikleri) |
| **İki alan (teknik / pedagojik)** | **Dual domain** (teknik + eğitimsel yetkinlik) | `CompetencyProfile`: technical_score, educational_score, dominant_domain, weak_domain |
| **Bilgi türleri** | **Nonaka & Takeuchi (1995)** – procedural, declarative, conditional knowledge | `recommendation_engine.py` → `create_user_vector()`: procedural_knowledge, declarative_knowledge, conditional_knowledge |
| **Öğrenme hedefi** | Dreyfus + hedef odaklı | `learning_goal`: novice/advanced_beginner→0.9, competent→0.6, proficient/expert→0.3 |
| **Benzerlik skoru S** | **Cosine similarity + Euclidean distance** (vektör benzerliği) | `calculate_similarity_score()`: user vec vs persona vec, hybrid 0.6·cos + 0.4·(1−norm_euclidean) |
| **Yetkinlik uyumu C** | **Zone of Proximal Development (Vygotsky)** – optimal zorluk | `calculate_competency_match()`: Gaussian exp(-λ·skill_gap²), alignment (pedagogical vs production) |
| **Performans tahmini P** | **Logistic regression** (pilot veriyle kalibre) | `predict_performance()`: σ(β₀+β₁·skill+β₂·quality+β₃·match+β₄·task_complexity) |
| **Öğrenme yörüngesi L** | **Power Law of Practice (Newell & Rosenbloom)** | `calculate_learning_trajectory()`: L_max·(1−e^(-k·t))·potential |
| **Tamamlayıcılık D** | Eksikleri kapatma (complementarity) | `calculate_complementarity()`: persona güçlü × kullanıcı zayıf alanlar |
| **Bilişsel yük** | **Cognitive Load Theory (Sweller, 1988)** | `calculate_intrinsic_load`, `calculate_extraneous_load`, `calculate_germane_load`, `calculate_total_cognitive_load` |
| **Çok kriterli karar** | **Multi-Criteria Decision Analysis (MCDA)** | `calculate_recommendation_score()`: R = α·S + β·C + γ·P + δ·L (veya complementary modda D) |
| **Dual mode** | Similar vs Complementary strateji | Similar: dominant alandan benzer; Complementary: weak alandan eksik tamamlayan |
| **Adaptif mod** | learning_goal’a göre otomatik mod | `mode="adaptive"`: learning_goal>0.7→complementary, <0.3→similarity, arası→hybrid |

Tüm bu teoriler, **kullanıcı bilgisi girişinden sonra** önce **CompetencyProfile**, sonra **UserVector**, sonra **persona skorları** hesaplanırken kullanılıyor.

---

## 3. Örnek Veri Üzerinden Adım Adım Hesaplama

### 3.1 Örnek Kullanıcı Girişleri (CAQ’tan)

Aşağıdaki veriler **CAQ (Competency Assessment Questionnaire)** formundaki bölümlerden alınmış örnek cevaplardır:

- **Demografik (CAQ Bölüm A):** Yaş 28, Eğitim: Lisans, Sektör: Teknoloji/Yazılım  
- **Teknik yetkinlik (CAQ Bölüm B – Likert 1–5):**  
  - Blockchain Teknolojileri (4 soru): 4, 4, 3, 3 → ortalama 3.5  
  - Genel Programlama (4 soru): 4, 4, 4, 3 → ortalama 3.75  
  - Tüm teknik (8 soru): (3.5+3.75)/2 ≈ **3.625**  
- **Pedagojik yetkinlik (CAQ Bölüm C – Likert 1–5):**  
  - Eğitim Teorileri ve Uygulamaları (4 soru): 2, 2, 3, 2 → 2.25  
  - İletişim ve Sunum Becerileri (4 soru): 3, 3, 2, 2 → 2.5  
  - Tüm pedagojik (8 soru): (2.25+2.5)/2 ≈ **2.375**  
- **Kendini değerlendirme (CAQ Bölüm F):** Dreyfus seviyesi = "Yetkin (Competent)"

---

### 3.2 Adım 1: CompetencyProfile (create_profile)

**Kaynak:** `competency_assessment.py` → `create_profile()`

- **technical (Likert):** tech_ soruları ortalaması = **3.625**  
- **educational (Likert):** edu_ soruları ortalaması = **2.375**  
- **technical_level:** `determine_level(3.625)`  
  - LEVELS: competent = [2.9, 3.8] → **competent**  
- **educational_level:** `determine_level(2.375)`  
  - advanced_beginner = [1.9, 2.8] → **advanced_beginner**  
- **0–100’e çevirme (Likert → 100):**  
  - `(likert - 1) / 4 * 100`  
  - technical_score = (3.625−1)/4×100 = **65.625**  
  - educational_score = (2.375−1)/4×100 = **34.375**  
- **overall_score:** (65.625 + 34.375) / 2 = **50**  
- **dominant_domain:** tech_score ≥ 40, edu_score < 40 → **technical** (güçlü alan)  
- **weak_domain:** **educational** (zayıf alan)

Özet profil:

- technical_score = 65.625, educational_score = 34.375  
- technical_level = competent, educational_level = advanced_beginner  
- dominant_domain = technical, weak_domain = educational  

---

### 3.3 Adım 2: profile_dict (Engine’e giren sözlük)

`get_persona_recommendations_from_profile(profile)` içinde:

```python
profile_dict = {
    "user_id": str(uuid.uuid4()),
    "technical_score": 65.625,   # 0-100
    "educational_score": 34.375,
    "technical_level": "competent",
    "educational_level": "advanced_beginner",
    "dominant_domain": "technical",
    "weak_domain": "educational",
    "learning_goal": 0.7
}
```

---

### 3.4 Adım 3: UserVector (create_user_vector)

**Kaynak:** `recommendation_engine.py` → `create_user_vector(profile_dict)`

- **score (0–1):**  
  - technical_score, educational_score 0–100 olduğu için:  
  - score = (65.625 + 34.375) / 2 / 100 = **0.5**  
- **level:** technical_level → **"competent"**  
- **domain:** dominant_domain → **"technical"**

**Parametreler (örnek score=0.5, level=competent):**

| Parametre | Formül / Kural | Örnek değer |
|-----------|----------------|-------------|
| technical_skill | level_mapping["competent"] | **0.5** |
| domain_knowledge | technical→0.8, educational→0.7 | **0.8** |
| ai_experience | responses.get('ai_experience') varsa 0.7, yoksa 0.2 | (varsayalım) **0.2** |
| learning_goal | competent → 0.6 | **0.6** |
| procedural_knowledge | min(1, score×1.2) | min(1, 0.6)=**0.6** |
| declarative_knowledge | score | **0.5** |
| conditional_knowledge | max(0.3, score−0.2) | max(0.3, 0.3)=**0.3** |
| cognitive_capacity | 0.5 + score×0.5 | 0.5+0.25=**0.75** |
| pattern_recognition | max(0.3, score−0.1) | max(0.3, 0.4)=**0.4** |
| abstraction_level | score | **0.5** |

Böylece **UserVector** tek bir kullanıcıyı 10 boyutlu vektör olarak temsil eder; bu vektör hem similarity hem complementary skorlarında kullanılır.

---

### 3.5 Adım 4: Similar Persona Seçimi (Dominant Domain = Technical)

- **Adaylar:** `ALL_PERSONAS` içinde `category == "technology"` olanlar:  
  tech_novice, tech_advanced_beginner, tech_competent, tech_proficient, tech_expert  
- Her biri için `calculate_recommendation_score(user_vector, persona_vector, task_complexity=0.5, mode="similarity")` çağrılır.

**Similarity modunda toplam skor:**

```
R_similar = α·S + β·C + γ·P + δ·L
α=0.30, β=0.35, γ=0.25, δ=0.10
```

**Tek bir persona (ör. tech_competent) için bileşenler:**

- **S (Similarity):**  
  - user_vec: [technical_skill, domain_knowledge, ai_experience, learning_goal, cognitive_capacity, abstraction_level]  
  - persona_vec: [technical_depth, technical_depth, innovation_factor, 1−production_readiness, 1−code_complexity, code_complexity]  
  - S = 0.6·cos_sim + 0.4·(1 − norm_euclidean).  
  - Örnek sayısal: **S ≈ 0.72** (sadece örnek; gerçek kodda numpy ile hesaplanır).

- **C (Competency match):**  
  - persona_difficulty = (code_complexity + technical_depth)/2  
  - user_skill = (technical_skill + domain_knowledge)/2  
  - Gaussian: exp(-2·(user_skill − persona_difficulty)²), alignment (learning_goal’a göre pedagogical_focus veya production_readiness), knowledge_match.  
  - Örnek: **C ≈ 0.68**.

- **P (Performance):**  
  - σ(β₀ + β₁·user_skill + β₂·persona_quality + β₃·match + β₄·task_complexity).  
  - Örnek: **P ≈ 0.71**.

- **L (Learning trajectory):**  
  - (1−e^(-k·t))·learning_support·learning_capacity.  
  - Örnek: **L ≈ 0.45**.

**Örnek toplam (tech_competent):**

- R_similar = 0.30×0.72 + 0.35×0.68 + 0.25×0.71 + 0.10×0.45 ≈ **0.68**.

Tüm technology persona’ları için R_similar hesaplanıp **en yüksek skoru alan** Similar persona olarak atanır (örnekte tech_competent veya tech_proficient çıkabilir).

---

### 3.6 Adım 5: Complementary Persona Seçimi (Weak Domain = Educational)

- **Adaylar:** `category == "education"` → edu_novice, edu_advanced_beginner, edu_competent, edu_proficient, edu_expert  
- Her biri için `calculate_recommendation_score(..., mode="complementary")` çağrılır.

**Complementary modda:**

```
R_complementary = α·(1−S) + β·D + γ·P + δ·L
```

- **(1−S):** Benzerlik değil, “farklılık” tercih edilir (zayıf alanda farklı/öğretici persona).  
- **D:** `calculate_complementarity(user, persona)`  
  - user_weaknesses: { technical: 1−technical_skill, domain: 1−domain_knowledge, ... }  
  - persona_strengths: { technical: technical_depth, domain: pedagogical_focus/production_readiness, ... }  
  - D = ortalama(persona_güçlü × kullanıcı_zayıf).  
  - Pedagojik odaklı persona’lar (education) zayıf “educational” kullanıcı için yüksek D verir.

Tüm education persona’ları skorlanıp **en yüksek R_complementary** değerini alan Complementary persona seçilir (ör. edu_competent veya edu_proficient).

---

### 3.7 Adım 6: Görev Ataması (Dual Mode – 3 Similar, 3 Complementary)

**Kaynak:** `assign_ai_persona_for_task(task_number, similar_persona, complementary_persona)`

- Görev 1, 3, 5 → **Similar AI** (aynı persona objesi)  
- Görev 2, 4, 6 → **Complementary AI** (aynı persona objesi)

Yani kullanıcı bilgisi girişinden çıkan **tek bir Similar** ve **tek bir Complementary** persona, 6 görev boyunca bu kurala göre kullanılır; görev bazında yeniden hesaplama yok.

---

## 4. Her Parametrenin Nasıl Hesaplandığı (Özet Tablo)

| Parametre | Kaynak | Formül / Mantık |
|-----------|--------|------------------|
| technical_score (0–100) | tech_* cevapları | Likert ortalama → (avg−1)/4×100 |
| educational_score (0–100) | edu_* cevapları | Aynı |
| technical_level | technical Likert ort. | LEVELS aralığına göre (novice..expert) |
| educational_level | educational Likert ort. | Aynı |
| dominant_domain | tech_score vs edu_score, 40 eşik | Büyük ve ≥40 olan dominant |
| weak_domain | Diğer alan | weak_domain |
| score (0–1) | technical_score, educational_score | (tech+edu)/2/100 |
| learning_goal | level | novice/adv_beginner→0.9, competent→0.6, üstü→0.3 |
| procedural_knowledge | score | min(1, score×1.2) |
| declarative_knowledge | score | score |
| conditional_knowledge | score | max(0.3, score−0.2) |
| cognitive_capacity | score | 0.5 + score×0.5 |
| pattern_recognition | score | max(0.3, score−0.1) |
| abstraction_level | score | score |
| S (similarity) | UserVector, PersonaVector | 0.6·cos_sim + 0.4·(1−norm_euclidean) |
| C (competency match) | UserVector, PersonaVector | Gaussian ZPD + alignment + knowledge_match |
| P (performance) | UserVector, PersonaVector, task_complexity | Sigmoid(linear combination) |
| L (learning trajectory) | UserVector, PersonaVector, time_factor | (1−e^(-k·t))·potential |
| D (complementarity) | UserVector, PersonaVector | Σ(persona_strong × user_weak)/n |
| R_similar | S, C, P, L | α·S + β·C + γ·P + δ·L |
| R_complementary | (1−S), D, P, L | α·(1−S) + β·D + γ·P + δ·L |

---

## 5. Adaptiflik Nereden Geliyor?

- **Profil bazlı:** Kullanıcı bilgisi girişi (Likert + Dreyfus + domain) → **CompetencyProfile** ve **UserVector** her kullanıcıya özel. Aynı form farklı cevaplar → farklı skorlar ve farklı Similar/Complementary persona çifti.  
- **learning_goal:** Dreyfus seviyesinden türetiliyor; engine içinde **adaptive** modda learning_goal’a göre otomatik olarak similarity / complementary / hybrid seçiliyor. Araştırma uygulamasında doğrudan **similarity** ve **complementary** modları ayrı ayrı kullanıldığı için (Similar için dominant, Complementary için weak domain), adaptiflik daha çok “hangi alan dominant/weak” ve “hangi persona seti aday” üzerinden gelir.  
- **Task complexity / time_factor:** İleride görev bazlı veya zaman bazlı ince ayar için kullanılabilir; şu an sabit (0.5).  
- **Fallback:** Matematiksel engine hata verirse **basit mod** (seviye bazlı kural) devreye girer; bu da seviyeye göre farklı persona önererek bir tür adaptasyon sağlar.

Yani adaptiflik: (1) kullanıcıya özel profil ve vektör, (2) dominant/weak domain’e göre farklı persona havuzu, (3) engine’deki mod (similarity/complementary/adaptive) ve (4) isteğe bağlı basit mod fallback ile sağlanıyor.

---

## 6. Dual Mode Nedir, Tüm Bilgiler

**Dual mode:** İki farklı öneri stratejisinin aynı anda kullanılması.

- **Similar (Benzerlik) modu:**  
  - **Amaç:** Kullanıcının **güçlü olduğu alanda** kendisine benzer bir AI (aynı domain, benzer seviye). Rahat çalışma, tanıdık zorluk.  
  - **Adaylar:** dominant_domain’e göre (technical → technology persona’ları, educational → education persona’ları).  
  - **Skor:** R = α·S + β·C + γ·P + δ·L (yüksek S tercih edilir).  
  - **Kullanım:** Görev 1, 3, 5.

- **Complementary (Tamamlayıcı) modu:**  
  - **Amaç:** Kullanıcının **zayıf olduğu alanda** eksiklerini tamamlayan AI (farklı domain veya öğretici karakter).  
  - **Adaylar:** weak_domain’e göre (educational → education persona’ları, technical → technology persona’ları).  
  - **Skor:** R = α·(1−S) + β·D + γ·P + δ·L (yüksek D ve farklılık tercih edilir).  
  - **Kullanım:** Görev 2, 4, 6.

**Özet:**

- Aynı kullanıcı bilgisi girişinden **iki persona** seçilir: biri Similar, biri Complementary.  
- Görevler 3+3 olarak bu iki moda atanır.  
- Teori: Benzerlik (rahatlık) ile tamamlayıcılık (öğrenme/eksik kapatma) dengesi; araştırma bu iki koşulu karşılaştırmak için kurgulanmış.

Bu belge, kullanıcı bilgilerini girdikten sonra ne olduğunu, hangi teorinin nerede kullanıldığını, örnek veriyle parametrelerin nasıl hesaplandığını, adaptifliği ve dual mode’u tek metinde toplar.
